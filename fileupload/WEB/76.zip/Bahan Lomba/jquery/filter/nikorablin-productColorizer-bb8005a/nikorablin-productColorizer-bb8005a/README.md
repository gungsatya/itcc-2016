productColorizer
================

jQuery plugin that makes it easy to add color to product images on the fly

Read more here:
http://nikorablin.com/sandbox/productColorizer/

Update 1.2
================

+ Fixed width issue

Update 1.1
================

+ Added support for multiple colors using raphael SVG library
+ Fixed ie bugs
+ Automatically generates span in color anchors