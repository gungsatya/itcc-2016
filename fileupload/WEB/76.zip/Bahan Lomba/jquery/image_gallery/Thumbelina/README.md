Thumbelina is a very lightweight content slider specifically designed for use with galleries of thumbnail images.

It integrates well with other plugins, and is a perfect solution where too many thumbnails would clutter the page.

See: www.starplugins.com/thumbelina
