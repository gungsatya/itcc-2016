Copyright 2013, Star Plugins, www.starplugins.com
License: GNU General Public License, version 3 (GPL-3.0)
http://www.opensource.org/licenses/gpl-3.0.html
